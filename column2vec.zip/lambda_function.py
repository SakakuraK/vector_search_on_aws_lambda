import json
import io
import boto3
import os
import compress_fasttext
import numpy as nmp

import csv

from chardet.universaldetector import UniversalDetector

GET_S3_BUCKET = os.environ['GET_S3_BUCKET']
PUT_S3_BUCKET = os.environ['PUT_S3_BUCKET']
GET_S3_DIRECTORY = os.environ['GET_S3_DIRECTORY']
PUT_S3_DIRECTORY = os.environ['PUT_S3_DIRECTORY']
GET_S3_FILE = os.environ['GET_S3_FILE']
PUT_S3_FILE = os.environ['PUT_S3_FILE']

WORD_VEC_BUCKET = os.environ['WORD_VEC_BUCKET']
WORD_VEC_DIRECTORY = os.environ['WORD_VEC_DIRECTORY']
WORD_VEC_FILE = os.environ['WORD_VEC_FILE']

def lambda_handler(event, context):
    
    s3 = boto3.client('s3')
    
    sentense_np = nmp.empty((0,100))# 文章のベクトル平均格納用
    sentense_array = []# 文章そのものを配列格納
    
    # 単語モデルを読み込み
    is_file = os.path.isfile('/tmp/'+WORD_VEC_FILE)
    if is_file:
        # tmpから消えてなければpass
        #print('ixist')
        pass
    else:
        # 無ければs3から持ってくる
        s3.download_file(WORD_VEC_BUCKET, WORD_VEC_DIRECTORY+WORD_VEC_FILE, '/tmp/'+WORD_VEC_FILE)
    
    small_model = compress_fasttext.models.CompressedFastTextKeyedVectors.load('/tmp/'+WORD_VEC_FILE)
    
    # ゲーム説明を読み込み
    is_file = os.path.isfile('/tmp/'+GET_S3_FILE)
    if is_file:
        # tmpから消えてなければpass
        print('ixist')
        #pass
    else:
        # 無ければs3から持ってくる
        s3.download_file(GET_S3_BUCKET, GET_S3_DIRECTORY+GET_S3_FILE, '/tmp/'+GET_S3_FILE)
    
    filename = '/tmp/'+GET_S3_FILE
    with open(filename, encoding='utf8', newline='') as f:
        csvreader = csv.reader(f)
        for row in csvreader:
            #print(row[0])
            #print('vec_dim->')
            #print(sentense_np.shape)
            #print(get_sentence_vec(small_model,row[0]).shape)
            sentense_np = nmp.vstack((sentense_np, get_sentence_vec(small_model,row[0])))
            #sentense_array.append(data)
    
    # ベクトル平均の次元数と数だけ確認
    #print(sentense_np.shape)
    
    nmp.save('/tmp/'+PUT_S3_FILE, sentense_np)
    
    s3.upload_file('/tmp/'+PUT_S3_FILE+'.npy', PUT_S3_BUCKET, PUT_S3_DIRECTORY+PUT_S3_FILE+'.npy')
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

# 分かち書きされた文章の単語のベクトル取ってそれの平均をreturn
def get_sentence_vec(small_model, sentence:str):
    
    vec_list=[]
    #tokens_list = sentence.split()
    tokens_list = sentence.replace('"', '').split()# 両端に「"」あるのでこれを除去してから
    
    if len(tokens_list) > 0:
        for token in tokens_list:
            vec_list.append(small_model.get_vector(token)) 
        
        sentence_vec  =  nmp.array(vec_list)
        #print(nmp.mean(sentence_vec, axis=0).shape)
        #print(nmp.empty((100, )).shape)
        
        return nmp.mean(sentence_vec, axis=0)
    else:
        # 文字無かったら空numpy返す
        return nmp.empty((100, ))
    
    