import json
import fasttext

import numpy as nmp

import ctypes
import compress_fasttext
import urllib.parse
import os

WORD_VEC_BUCKET = os.environ['WORD_VEC_BUCKET']
WORD_VEC_DIRECTORY = os.environ['WORD_VEC_DIRECTORY']
WORD_VEC_FILE = os.environ['WORD_VEC_FILE']

#from sudachipy import tokenizer
#from sudachipy import dictionary

import boto3
translate = boto3.client('translate')

#tokenizer_obj = dictionary.Dictionary(dict_type="small").create()

# sudachiで分割
#mode = tokenizer.Tokenizer.SplitMode.B

# 入力した文章をsudachiで分割して返す関数
#def sdc_tokenized_sentense(tgt_senetense):
#  return ' '.join([m.surface() for m in tokenizer_obj.tokenize(tgt_senetense, mode)])

def lambda_handler(event, context):
    
    s3 = boto3.client('s3')
    # 単語モデルを読み込み
    is_file = os.path.isfile('/tmp/'+WORD_VEC_FILE)
    if is_file:
        # tmpから消えてなければpass
        #print('ixist')
        pass
    else:
        # 無ければs3から持ってくる
        s3.download_file(WORD_VEC_BUCKET, WORD_VEC_DIRECTORY+WORD_VEC_FILE, '/tmp/'+WORD_VEC_FILE)
    
    small_model = compress_fasttext.models.CompressedFastTextKeyedVectors.load('/tmp/'+WORD_VEC_FILE)
    
    
    #print(small_model.get_vector("shooting"))
    
    #input_text ='日本で暮らしています'
    input_text = urllib.parse.unquote(event)# URL decode
    #print('input_text->',input_text)
    
    # 日→英翻訳
    response = translate.translate_text(
        Text=input_text,
         SourceLanguageCode='ja',
        TargetLanguageCode='en'
    )
    
    output_text =response.get('TranslatedText')
    #print('output_text->',output_text)
    
    # 文章のベクトル平均
    sentence_vec_mean = get_sentence_vec(small_model, output_text)
    
    #print(sentence_vec_mean)
    #print(type(sentence_vec_mean))
    return sentence_vec_mean.tolist()
    
    

# 分かち書きされた文章の単語のベクトル取ってそれの平均をreturn
def get_sentence_vec(small_model, sentence:str):
    
    vec_list=[]
    tokens_list = sentence.split()
    
    for token in tokens_list:
        vec_list.append(small_model.get_vector(token)) 
    
    sentence_vec  =  nmp.array(vec_list)
    
    return nmp.mean(sentence_vec, axis=0)