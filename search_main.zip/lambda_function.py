import json
import boto3
import urllib.parse
import os

INVOKE_FUNCTION_1_TEXT2VEC = os.environ['INVOKE_FUNCTION_1_TEXT2VEC']
INVOKE_FUNCTION_2_SEARCH_FAISS = os.environ['INVOKE_FUNCTION_2_SEARCH_FAISS']
INVOKE_FUNCTION_3_SEARCH_CSV = os.environ['INVOKE_FUNCTION_3_SEARCH_CSV']

def lambda_handler(event, context):

    
    #print("---XX: input_word_url:", event['pathParameters']['sub'])
    #print("---XX: input_word_decode:", urllib.parse.unquote(event['pathParameters']['sub']))
    # event['pathParameters']['sub'] ここにURLのパラメータが

    #Payload1 = json.dumps(input_event) # jsonシリアライズ
    Payload1 = json.dumps(event['pathParameters']['sub']) #URLパラメータに来た引数
    

    # f1呼び出し
    response1 = boto3.client('lambda').invoke(
        FunctionName=INVOKE_FUNCTION_1_TEXT2VEC,
        InvocationType='RequestResponse',
        Payload=Payload1
    )
    
    Payload2 = response1['Payload'].read()
    
    # f2呼び出し
    response2 = boto3.client('lambda').invoke(
        FunctionName=INVOKE_FUNCTION_2_SEARCH_FAISS,
        InvocationType='RequestResponse',
        Payload=Payload2
    )
    '''
    ret_json = response2['Payload'].read()
    print('ret_json->',ret_json)
    print('type_ret_json->')
    print(type(ret_json))
    #for a in ret_json:
    #    print(a)
    
    return {
        'statusCode': 200,
        'body': ret_json
    }
    
    '''
    Payload3 = response2['Payload'].read()
    
    # f3呼び出し
    response3 = boto3.client('lambda').invoke(
        FunctionName=INVOKE_FUNCTION_3_SEARCH_CSV,
        InvocationType='RequestResponse',
        Payload=Payload3
    )


    # レスポンス読出し
    #ret_json = json.loads(response3['Payload'].read()) #どうやらHTTPヘッダーは特殊な形をしているようで、普通にjson.
    ret_json = response3['Payload'].read()
    
    print('type_ret_json->')
    print(type(ret_json))
    
    return {
        'statusCode': 200,
        'body': ret_json
    }
    
    
    #return res