import json
import io
import boto3
import os
import time
import faiss
import numpy as nmp

GET_S3_BUCKET = os.environ['GET_S3_BUCKET']
PUT_S3_BUCKET = os.environ['PUT_S3_BUCKET']
GET_S3_DIRECTORY = os.environ['GET_S3_DIRECTORY']
PUT_S3_DIRECTORY = os.environ['PUT_S3_DIRECTORY']
GET_S3_FILE = os.environ['GET_S3_FILE']
PUT_S3_FILE = os.environ['PUT_S3_FILE']

def lambda_handler(event, context):
    
    s3 = boto3.client('s3')
    # vectorの入ったnumpyを読み込み
    is_file = os.path.isfile('/tmp/'+GET_S3_FILE)
    if is_file:
        # tmpから消えてなければpass
        #print('ixist')
        pass
    else:
        # 無ければs3から持ってくる
        s3.download_file(GET_S3_BUCKET, GET_S3_DIRECTORY+GET_S3_FILE, '/tmp/'+GET_S3_FILE)
    
    vector_numpy = nmp.load('/tmp/'+GET_S3_FILE)
    
    time_sta = time.time()
    indexhnsw = faiss.IndexHNSWFlat(100, 32)
    indexhnsw.train(vector_numpy)
    indexhnsw.add(vector_numpy)
    time_end = time.time()
    
    tim = time_end- time_sta

    #print(tim)
    
    faiss.write_index(indexhnsw, '/tmp/'+PUT_S3_FILE)
    s3.upload_file('/tmp/'+PUT_S3_FILE, PUT_S3_BUCKET, PUT_S3_DIRECTORY+PUT_S3_FILE)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
