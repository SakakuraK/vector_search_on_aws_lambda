import json
import os

import faiss
import numpy as nmp
import boto3

GET_S3_BUCKET=os.environ['GET_S3_BUCKET']
GET_S3_DIRECTORY=os.environ['GET_S3_DIRECTORY']
GET_S3_FILE=os.environ['GET_S3_FILE']

def lambda_handler(event, context):
    # eventに渡されるのはベクトルデータlist これでfaissから検索
    s3 = boto3.client('s3')
    
    # faissを読み込み
    is_file = os.path.isfile('/tmp/'+GET_S3_FILE)
    if is_file:
        # tmpから消えてなければpass
        #print('ixist')
        pass
    else:
        # 無ければs3から持ってくる
        s3.download_file(GET_S3_BUCKET, GET_S3_DIRECTORY+GET_S3_FILE, '/tmp/'+GET_S3_FILE)
    
    
    index = faiss.read_index('/tmp/'+GET_S3_FILE)
    #リスト型listをNumPy配列ndarrayに変換 dimも調整
    query = nmp.array(event).reshape(1,100)
    #print('query.shape')
    #print(query.shape)
    
    # インデックスから近似検索
    I = index.search(query, 3)
    #print('I.shape')
    #print(I.shape)
    #print('I')
    #print(I)
    '''
    I = [18,25,27]
    '''
    return I[1].tolist()

    
    #print("呼ばれています")
    #return event