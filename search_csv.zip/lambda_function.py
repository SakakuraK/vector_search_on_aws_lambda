import json
import pandas as pd
import io
import boto3
import os

BUCKET_NAME=os.environ['BUCKET_NAME']
DIRECTORY=os.environ['DIRECTORY']
CSV_NAME=os.environ['CSV_NAME']

def lambda_handler(event, context):
    # eventに渡ってくるのはfaiss検索で取ったindex3つ +1で行数と一致するのでこれをCSVから該当行抽出
    # [[15878, 15587, 3203]] こういう形状で来る event[0][1] で二個目
    
    s3 = boto3.client('s3')
    # csvを読み込み
    is_file = os.path.isfile('/tmp/'+CSV_NAME)
    if is_file:
        # tmpから消えてなければpass
        print('ixist')
        #pass
    else:
        # 無ければs3から持ってくる
        s3.download_file(BUCKET_NAME, DIRECTORY+CSV_NAME, '/tmp/'+CSV_NAME)
    
    df_in = pd.read_csv('/tmp/'+CSV_NAME)
    
    #print(df_in.loc[8].to_json())
    #print('-----------------')
    #df_in[5:5]
    
    
    #print(event)
    
    #print(event[0])
    
    #print(json.loads(df_in.loc[0].to_json()))
    
    data_list = []
    #data_list.append(df_in.loc[18].to_json())
    #data_list.append(df_in.loc[28].to_json())
    #data_list.append(df_in.loc[58].to_json())
    data1 = json.loads(df_in.loc[event[0][0]].to_json())
    data2 = json.loads(df_in.loc[event[0][1]].to_json())
    data3 = json.loads(df_in.loc[event[0][2]].to_json())
    '''
    data1 = json.loads(df_in.loc[18].to_json())
    data2 = json.loads(df_in.loc[308].to_json())
    data3 = json.loads(df_in.loc[3009].to_json())
    '''
    
    
    
    
    data_list = [data1,data2,data3]
    #data_list = json.dumps(data_list, indent=4)
    #print(data_list)
    
    return {
        'statusCode': 200,
        'body': data_list
    }
