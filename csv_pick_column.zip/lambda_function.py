import json
import pandas as pd
import io
import boto3
import os

from chardet.universaldetector import UniversalDetector

TARGET_S3_BUCKET = os.environ['TARGET_S3_BUCKET']
GET_S3_DIRECTORY = os.environ['GET_S3_DIRECTORY']
PUT_S3_DIRECTORY = os.environ['PUT_S3_DIRECTORY']
GET_S3_FILE = os.environ['GET_S3_FILE']
PUT_S3_FILE = os.environ['PUT_S3_FILE']
PICK_COLUMN = os.environ['PICK_COLUMN']

def lambda_handler(event, context):
    
    s3 = boto3.client('s3')
    # ふぁいるを読み込み
    is_file = os.path.isfile('/tmp/'+GET_S3_FILE)
    if is_file:
        # tmpから消えてなければpass
        print('ixist')
        #pass
    else:
        # 無ければs3から持ってくる
        s3.download_file(TARGET_S3_BUCKET, GET_S3_DIRECTORY+GET_S3_FILE, '/tmp/'+GET_S3_FILE)
    
    
    # ちょっと文字コード判定
    '''
    filepath = '/tmp/'+GET_S3_FILE
    with open(filepath, 'rb') as f:  
        detector = UniversalDetector()
        for line in f:
            detector.feed(line)
            if detector.done:
                break
        detector.close()
        result = detector.result
    
    print('code->',result)
    '''
    
    df = pd.read_csv('/tmp/'+GET_S3_FILE) 

    df[PICK_COLUMN].to_csv('/tmp/'+PUT_S3_FILE, header = None,  index = None)
    
    filepath = '/tmp/'+PUT_S3_FILE
    with open(filepath, 'rb') as f:  
        detector = UniversalDetector()
        for line in f:
            detector.feed(line)
            if detector.done:
                break
        detector.close()
        result = detector.result
    
    print(filepath+' code->',result)
    
    
    s3.upload_file('/tmp/'+PUT_S3_FILE, TARGET_S3_BUCKET, PUT_S3_DIRECTORY+PUT_S3_FILE)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
